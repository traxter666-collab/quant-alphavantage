import os
import requests

# Get API key
api_key = os.getenv('ALPHAVANTAGE_API_KEY', 'ZFL38ZY98GSN7E1S')
print(f"Using API Key: {api_key[:4]}...{api_key[-4:]}")

# Test SPY quote
url = f"https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=SPY&apikey={api_key}"
response = requests.get(url)
data = response.json()

print("\nSPY Quote Test:")
if "Global Quote" in data:
    quote = data["Global Quote"]
    price = quote.get("05. price", "N/A")
    change = quote.get("09. change", "N/A")
    print(f"SPY Price: ${price}")
    print(f"Change: {change}")
    print("SUCCESS: API key is working!")
    
    # Calculate SPX estimate
    if price != "N/A":
        spx_estimate = float(price) * 10
        print(f"SPX Estimate: ${spx_estimate:.2f}")
else:
    print("ERROR:", data)